#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Dec  2 21:00:42 2020

@author: maekhaled
"""

import subprocess


program_list = ['data_load.py','import_settings.py', 'import_data.py', 'forecast_demand.py','outage_simulation.py', 'reinforcement_learning.py','PlotOptimalPolicy.py','pdfmaker.py']


for program in program_list:
    subprocess.call(['python', program])
    print("Finished:" + program)