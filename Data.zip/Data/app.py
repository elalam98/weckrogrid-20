#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Nov 28 22:05:33 2020

@author: luisaweiss
"""
import os
from flask import Flask, request,redirect, jsonify
from flask import render_template
app = Flask(__name__)





@app.route('/')
def index():
    
    return render_template('index.html')


@app.route('/test', methods=['GET','POST'])
def example():
    
    person = list(request.form.values())[0]

    email = list(request.form.values())[1]
    
    
    #requestJson = request.get_json(force=True)
    
    return render_template('page2.html')

@app.route('/page3.html')
def page3():
    
    return render_template('page3.html')

@app.route('/result',methods=['GET','POST'])
def results():
    
    data = request.json
    print(data)
    return render_template('index.html')
    
    
    
    
    


if __name__ == '__main__':
    app.run(debug=True, port=8000)
    
    