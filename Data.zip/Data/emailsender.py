#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Dec  3 19:33:25 2020

@author: maekhaled
"""
import email, smtplib, ssl
import os
from email import encoders
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.image import MIMEImage

body =  """\
<html>
  <head></head>
    <body>
      <img src="cid:image1" alt="Logo" style="width:250px;height:50px;"><br>
       <p><h4 style="font-size:15px;">Some Text.</h4></p>           
    </body>
</html>
"""    

#Attached are your results! 

#Feel free to reply to this message if you have any questions.
#        We look forward to working with you soon.

#            Thank you for using Weckrogrid-20!                     
sender_email = "WeckroGrid-20"
receiver_email = "elalam98@gmail.com"

# Create a multipart message and set headers
message = MIMEMultipart()
message["From"] = 'WeckroGrid-20'
#message["To"] = 'elalam98@gmail.com'
message["Subject"] = 'Your Microgrid Plan is here!'
#message["Bcc"] = 'receiver_email'  # Recommended for mass emails

# Add body to email
#message.attach(MIMEText(body, "plain"))

filename = "dummy.pdf"  # In same directory as script

# Open PDF file in binary mode
with open(filename, "rb") as attachment:
    # Add file as application/octet-stream
    # Email client can usually download this automatically as attachment
    part = MIMEBase("application", "octet-stream")
    part.set_payload(attachment.read())
    
messageText = MIMEText('<br><img src="cid:weckroemail.jpg"><br>', 'html')
message.attach(messageText)
    
fp = open('weckroemail.jpg', 'rb')
messageImage = MIMEImage(fp.read())
fp.close()

messageImage.add_header('Content-ID', '<image1>')
message.attach(messageImage)

# Encode file in ASCII characters to send by email    
encoders.encode_base64(part)

# Add header as key/value pair to attachment part
part.add_header(
    "Content-Disposition",
    f"attachment; filename= {filename}",
)
#Add attachment to message and convert message to string
message.attach(part)
text = message.as_string('')

# Log in to server using secure context and send email
context = ssl.create_default_context()
with smtplib.SMTP_SSL("smtp.gmail.com", 465, context=context) as server:
    server.login('Weckrogrid20@gmail.com', 'jafari1234')
    server.sendmail(sender_email, receiver_email, text)