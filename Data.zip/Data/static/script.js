
const btn = document.querySelector('button');
function sendData(){

  console.log("you pressed da button");

}






let mainCont = document.getElementById("main-container");

let question1 = `<h2>“1.Choose the facility that you wish to power”</h2>
<div class="box-container">
<div class="box" id="hospital">
  <label> <input type="checkbox" for="hospital"/>
 
  <img src="./images/O1234utpatient Icon.png" alt="" />
 Hospital
  </label>
  <br/>
  Quantity
  <br/>
  <input type="number" min="0" value="0"/>
</div>

<div class="box" id="outpatient">
  <label> <input type="checkbox" for="outpatient"/>
  <img src="../static/images/Outpatient Icon.png" alt="" />
  Outpatient </label>
  <br/>
  Quantity
  <br/>
  <input type="number" min="0" value="0"/>
</div>

<div class="box" id="supermarket">
  <label> <input type="checkbox" for="supermarket"/>
  <img src="../static/images/Supermarket Icon.png" alt="">
  Supermarket </label>
  <br/>
  Quantity
  <br/>
  <input type="number" min="0" value="0"/>
</div>

<div class="box" id="hotel">
    <label> <input type="checkbox" for="hotel"/>
    <img src="../static/images/Hotel Icon.png" alt="">
    Hotel </label>
    <br/>
    Quantity
    <br/>
    <input type="number" min="0" value="0"/>
</div>

<div class="box" id="office">
    <label> <input type="checkbox" for="office"/>
    <img src="../static/images/Office Icon.png" alt="">
    Office </label>
    <br/>
    Quantity
    <br/>
    <input type="number" min="0" value="0"/>
</div>

<div class="box" id="school">
    <label> <input type="checkbox" for="school"/>
    <img src="../static/images/School Icon.jpg" alt="">
    School </label>
    <br/>
    Quantity
    <br/>
    <input type="number" min="0" value="0"/>
</div>

<div class="box" id="restaurant">
    <label> <input type="checkbox" for="restaurant"/>
    <img src="../static/images/Restaurant Icon.png" alt="">
    Restaurant </label>
    <br/>
    Quantity
    <br/>
    <input type="number" min="0" value="0"/>
</div>

<div class="box" id="residential">
    <label> <input type="checkbox" for="residential"/>
    <img src="../static/images/Residential Icon.png" alt="">
    Residential </label>
    <br/>
    Quantity
    <br/>
    <input type="number" min="0" value="0"/>
</div>
</div>`;

let question2 = `<h1>“2. Choose your preferred power source”</h1>
<div class="box-container">
<div class="box">
<label>
<input type="checkbox" >
<img src="../static/images/Solar Power Image.png"/>
<h4>Solar Power</h4>
<p>Solar power is pollution free and causes no greenhouse gases to be emitted after installation.</p>
</label>
<br/>
Quantity
<br/>
<input type="number" min="0" value="0"/>
</div>

<div class="box">
<label>
<input type="checkbox">
<img src="../static/images/Offshore Wind Power Image" alt="">
<h4>Offshore Wind Power</h4>
<p> Provide jobs and do not emit environmental pollutants or greenhouse gases (preference for near shore facilities) </p>
</label>
<br/>
Quantity
<br/>
<input type="number" min="0" value="0"/>
</div>

<div class="box">
<label>
<input type="checkbox">
<img src="./images/Onshore Wind Power Image" alt="">
<h4>Onshore Wind Power</h4>
<p> Provide jobs and do not emit environmental pollutants or greenhouse gases (preference for inland facilities) </p>
</label>
<br/>
Quantity
<br/>
<input type="number" min="0" value="0"/>
</div>

<div class="box">
<label>
<input type="checkbox">
<img src="./images/Diesel Power Image.png" alt="">
<h4>Diesel Power</h4>
<p> Fuel that is available without any weather conditions. Does not suffer loss in efficiency as technology improves</p>
</label>
<br/>
Quantity
<br/>
<input type="number" min="0" value="0"/>
</div>

</div>`;

let question3 = `<h1>3. Choose your preferred power storage”</h1>
<div class="box-container">
<div class="box">
<label>
<input type="checkbox" >
<img src="./images/Li-Ion Storage Image.png" alt="">
<h4>Tesla Powerwall</h4>
<h5>Li-Ion Battery</h5>
<p>Nickel-cobalt-aluminum (NCA) battery. Higher energy density, voltage capacity and lower self-discharge rate,  causes longer charge retention than other battery types.</p>
</label>
<br/>
Quantity
<br/>
<input type="number" min="0" value="0"/>
</div>

<div class="box">
<label>
<input type="checkbox">
<img src="./images/Vanadium Redox Storage Image.png" alt="">
<h4>Avalon and Red T</h4>
<h5>Vanadium Redox battery</h5>
<p>Unlimited energy capacity by using larger electrolyte storage tanks; it can be left completely discharged for long periods with no ill effects</p>
</label>
<br/>
Quantity
<br/>
<input type="number" min="0" value="0"/>
</div>

<div class="box">
<label>
<input type="checkbox">
<img src="./images/Lead-Acid Storage Image.png" alt="">
<h4>East Penn Manufacturing</h4>
<h5>Lead-Acid battery</h5>
<p>Cheapest secondary power source, it is almost fully recyclable and is intrinsically safe equipment. Its only disadvantage is the low specific energy (Wh kg−1)</p>
</label>
<br/>
Quantity
<br/>
<input type="number" min="0" value="0"/>
</div>

<div class="box">
<label>
<input type="checkbox">
<img src="./images/FlyWheel Storage Image.png" alt="">
<h4>Levisys</h4>
<h5>Flywheel Battery</h5>
<p>Flywheels are the oldest type of energy storage devices. The advantages of flywheel energy storage systems are high efficiency, high energy and power density, and long life.</p>
</label>
<br/>
Quantity
<br/>
<input type="number" min="0" value="0"/>
</div>

<div class="box">
<label>
<input type="checkbox">
<img src="./images/Pumped Hydro Storage Image.png" alt="">
<h4>NextEra</h4>
<h5>Pumped Hydro Battery</h5>
<p>Once built, these systems boast a very low cost of storage, and they hold truly massive amounts of energy compared to even the world’s biggest battery. </p>
</label>
<br/>
Quantity
<br/>
<input type="number" min="0" value="0"/>
</div>

</div>`;

let questions = [question1, question2, question3];
let qNo = 0;
const generateQuestion = () => {
  mainCont.innerHTML = questions[qNo];
};
generateQuestion();

let nextBtn = document.getElementById("next-btn");
let boxes = document.querySelectorAll(".box");

let result1 = [];
let result2 = [];
let result3 = [];
let results = [result1, result2, result3];

function boxesLoop() {
  for (let i = 0; i < boxes.length; i++) {
    let box = boxes[i];
    let checkBox = box.firstElementChild.firstElementChild;
    box.addEventListener("click", function () {
      if (checkBox.checked == true && qNo == 0) {
        checkBox.parentElement.parentElement.style.border = "4px solid #007bff";
      } else if (checkBox.checked == true && qNo == 1) {
        checkBox.parentElement.parentElement.style.border = "4px solid #007bff";
      } else if (checkBox.checked == true && qNo == 2) {
        checkBox.parentElement.parentElement.style.border = "4px solid #007bff";
      } else if (checkBox.checked == false) {
        checkBox.parentElement.parentElement.style.border = "4px solid #ffffff";
      }
    });
  }
}
boxesLoop();

nextBtn.addEventListener("click", function () {
  for (let i = 0; i < boxes.length; i++) {
    let box = boxes[i];
    let checkBox = box.firstElementChild.firstElementChild;

    if (checkBox.checked == true && qNo == 0) {
      result1.push({
        name: checkBox.parentElement.parentElement.id,
        value: checkBox.parentElement.parentElement.lastElementChild.value,
      });
    } else if (checkBox.checked == true && qNo == 1) {
      result2.push({
        name: checkBox.parentElement.children[2].innerText,
        value: checkBox.parentElement.parentElement.lastElementChild.value,
      });
    } else if (checkBox.checked == true && qNo == 2) {
      result3.push({
        name: checkBox.parentElement.children[3].innerText,
        value: checkBox.parentElement.parentElement.lastElementChild.value,
      });
    }
  }
  if (qNo == questions.length - 1) {
    localStorage.setItem("results", JSON.stringify(results));
    window.location.assign("./page3.html");
  }
  qNo++;
  generateQuestion();
  boxes = document.querySelectorAll(".box");
  boxesLoop();
});
