let results = JSON.parse(localStorage.getItem("results"));
let resultCont = document.getElementById("results");
let result1 = results[0];
let result2 = results[1];
let result3 = results[2];

let r1 = "";
let r2 = "";
let r3 = "";

for (let i = 0; i < result1.length; i++) {
  r1 += `<li>${JSON.stringify(result1[i].name)} - ${JSON.stringify(
    result1[i].value
  )}</li>`;
}
for (let i = 0; i < result2.length; i++) {
  r2 += `<li>${JSON.stringify(result2[i].name)} - ${JSON.stringify(
    result2[i].value
  )}</li>`;
}
for (let i = 0; i < result3.length; i++) {
  r3 += `<li>${JSON.stringify(result3[i].name)} - ${JSON.stringify(
    result3[i].value
  )}</li>`;
}
/*
window.addEventListener("load", function() {
  var mySocket = new WebSocket("ws://localhost:8000/result")
  mySocket.onMessage = function(event) {
    var output = document.getElementById("output");
    output.textContent = event.data;
  };
  var form = document.getElementsByClassName("foo");
  var input = document.getElementById("input");
  form[0].addEventListener("submit", function(e) {
    input_text = r1.value;
    mySocket.send(input_text);
    e.preventDefault()
  })
});

*/
var xmlhttp = new XMLHttpRequest();   // new HttpRequest instance 
var theUrl = "/result";
xmlhttp.open("POST", theUrl);
xmlhttp.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
//xmlhttp.send(JSON.stringify({ "email": "hello@user.com", "response": { "name": "Tester" } }));
var r6 = '{"product_id":"111", "customer_name":"xiaokun", "customer_phone":"1231"}'

xmlhttp.send(JSON.stringify(result1));

resultCont.innerHTML = `
<br/>
<br/>
<h4>Step 1</h4>
<ul>
${r1}
</ul>
<br/>
<h4>Step 2</h4>
<ul>
${r2}
</ul>
<br/>
<h4>Step 3</h4>
<ul>
${r3}
</ul>

`;
