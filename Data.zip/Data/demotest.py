#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Dec  3 20:59:58 2020

@author: maekhaled
"""
#optimal_policy = [('Lithium-Ion',9500),('Solar',20000),('Offshore Wind',8),('Onshore Wind',10),('Pumped Hydro',0),('Pumped Hydro',0),('Pumped Hydro',0),('Pumped Hydro',0),('Pumped Hydro',0),('Flywheel',0),('Flywheel',0),('Flywheel',0),('Vanadium Redox',3500),('Lithium-Ion',3500),('Solar',20000),('Flywheel',0),('Flywheel',0),('Pumped Hydro',0),('Pumped Hydro',0),('Offshore Wind',10)]


import random
#from import_settings import *
import numpy as np
import PIL.Image
from PIL import ImageTk, Image
from matplotlib.figure import Figure 
from matplotlib.pyplot import figure
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import (FigureCanvasTkAgg, NavigationToolbar2Tk) 
import pandas as pd
import numpy as np
from matplotlib.lines import Line2D
from matplotlib.font_manager import FontProperties


# plot function is created for  
# plotting the graph in  
# tkinter window 

y = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20]
fig, axes = plt.subplots(ncols=2, sharey=True, figsize=(10, 6))
plt.suptitle('Optimal Actions')
plt.yticks(np.arange(1,21,1))
plt.rcParams['figure.facecolor'] = 'whitesmoke'
width= 0.5
axes[0].invert_yaxis
axes[0].xaxis.set_label_position('top') 
axes[1].xaxis.set_label_position('top')
axes[0].yaxis.set_label_coords(1.14,.99)

ppquantity = [0,0,0,0,0]
suquantity = [0,0,0,0,0]
ppcost = [0,0,0,0,0]
sucost = [0,0,0,0,0]
totalqpp=0
totalqsu=0
totalcpp=0
totalcsu=0
tabledata = []
table2data = []
table3data = []


storage_units_list = ['Lithium-Ion', 'Lead Acid', 'Vanadium Redox', 'Flywheel', 'Pumped Hydro']
power_plants_list = ['Solar', 'Onshore Wind', 'Offshore Wind', 'Diesel', 'Hydro']
storage_color = ['lightcoral','maroon','red','lightsalmon','darkorange']
power_color = ['aqua','dodgerblue', 'blue', 'navy', 'teal']


optimal_policy = [('Lithium-Ion',9500),('Solar',20000),('Offshore Wind',8),('Onshore Wind',10),('Pumped Hydro',0),('Pumped Hydro',0),('Pumped Hydro',0),('Pumped Hydro',0),('Pumped Hydro',0),('Flywheel',1750),('Flywheel',0),('Flywheel',0),('Vanadium Redox',3500),('Lithium-Ion',3500),('Solar',20000),('Flywheel',0),('Flywheel',0),('Pumped Hydro',0),('Pumped Hydro',0),('Offshore Wind',10)]
rewards_path = [8329046.89,8851252.87,25756512.89,4843104.94,0,0,0,0,0,0,0,0,1772631.24,3068633.06,8652407.24,0,6391398.54,0,0,29248650.27]

for i in range(len(optimal_policy)):
    
    
    if optimal_policy[i][0] in storage_units_list:
        
        index = storage_units_list.index(optimal_policy[i][0])
        
        suquantity[index] += optimal_policy[i][1]
        
        sucost[index] += rewards_path[i]
        
        totalqsu += optimal_policy[i][1]
        
        totalcsu += rewards_path[i]
        
        color = storage_color[index]
        
        axes[0].barh(i+1, optimal_policy[i][1],  width,align='center',  color= color, label= optimal_policy[i][0])
        
        type = ' storage units'

    if optimal_policy[i][0] in power_plants_list:
        
        index = power_plants_list.index(optimal_policy[i][0])
        
        ppquantity[index] += optimal_policy[i][1]
        
        ppcost[index] += rewards_path[i]
        
        totalqpp += optimal_policy[i][1]
        
        totalcpp += rewards_path[i]
        
        color = power_color[index]

        axes[1].barh(i+1, optimal_policy[i][1], width,align='center', color= color, label= optimal_policy[i][0])
        
        type = ' power plants'
        
    tabledata.append([optimal_policy[i][0] + type, optimal_policy[i][1], rewards_path[i]])
    
   #label= optimal_policy[i][0]

for i in range(len(suquantity)):
    table2data.append([suquantity[i], sucost[i]])
    
for i in range(len(ppquantity)):
    table3data.append([ppquantity[i], ppcost[i]])    
 
   

    
    
    
axes[0].invert_xaxis()
axes[0].yaxis.tick_right()
axes[1].yaxis.tick_left()
axes[0].tick_params(pad=15)
axes[1].tick_params(pad=15)
axes[0].set_xlabel('Storage Units (kWh)', fontsize=15)
axes[1].set_xlabel('Power Plants (kW)', fontsize=15)
axes[0].set_ylabel('Year', fontsize= 15, rotation=0, va= 'center')
fontP = FontProperties()
fontP.set_size('x-small')

handles0 = [Line2D([0], [0], color='lightcoral', lw=4, label='Lithium-Ion'),Line2D([0], [0], color='maroon', lw=4, label='Lead Acid'), Line2D([0], [0], color='red', lw=4, label='Vanadium Redox'), Line2D([0], [0], color='lightsalmon', lw=4, label='Flywheel'), Line2D([0], [0], color='darkorange', lw=4, label='Pumped Hydro')]

handles1 = [Line2D([0], [0], color='aqua', lw=4, label='Solar'), Line2D([0], [0], color='dodgerblue', lw=4, label='Onshore Wind'), Line2D([0], [0], color='blue', lw=4, label='Offshore Wind'),Line2D([0], [0], color='navy', lw=4, label='Diesel')]                                                 
                                                              
axes[0].legend(handles = handles0,loc= 'upper left', bbox_to_anchor = (-0.4,1),prop=fontP)

axes[1].legend(handles = handles1,loc= 'upper right',bbox_to_anchor = (1.4,1),prop=fontP)

plt.tight_layout()

plt.show()
fig.savefig('plot.png')
#Create overall table

fig, ax = plt.subplots()

ax.xaxis.set_visible(False) 
ax.yaxis.set_visible(False)

columns = ('Investment Type', 'Quantity','Investment Cost ($)')

rows = ['Year %d' % x for x in range(1,21)]

results_table = plt.table(cellText = tabledata, rowLabels=rows, colLabels=columns, loc = 'center')
plt.show()
fig.savefig('table1.png')

# Create Storage Units Table
fig, ax = plt.subplots()

ax.xaxis.set_visible(False) 
ax.yaxis.set_visible(False)

storage_units_list2 = ['Lithium-Ion', 'Lead Acid', 'Vanadium Redox', 'Flywheel', 'Pumped Hydro', 'Total of All Storage Units']

columns = ('Total Quantity Invested', 'Total Investment Cost ($)')

rows = storage_units_list2

table2data.append([totalqsu,totalcsu])

su_table = plt.table(cellText = table2data, rowLabels=rows, rowLoc='right', colWidths=[0.25 for x in columns], colLabels=columns, loc = 'center right')
            
plt.show()
fig.savefig('table2.png')
# Create Power Plants Table
fig, ax = plt.subplots()

ax.xaxis.set_visible(False) 
ax.yaxis.set_visible(False)

power_plants_list2 = ['Solar', 'Onshore Wind', 'Offshore Wind', 'Diesel', 'Hydro', ' Total of All Power Plants']

columns = ('Total Quantity Invested', 'Total Investment Cost($)')

rows = power_plants_list2

table3data.append([totalqpp,totalcpp])

pp_table = plt.table(cellText = table3data, rowLabels=rows, rowLoc='right', colWidths=[0.25 for x in columns], colLabels=columns, loc = 'center right')

    
plt.show()
fig.savefig('table3.png')

print('Figures created and saved')


# pdf maker

from fpdf import FPDF
#from PIL import image
import import_settings

   
title = 'Your Microgrid Development Plan'
title1 = 'WECKro-Grid 20 Report'

class PDF(FPDF):
   
    def header(self):
        # Logo
        image = 'logo1.jpeg'
        pdf.image(image, 10, 8, 33, 8)
        
        
        #self.image('foo.png', 20, 20, 50)
        # Arial bold 15
        self.set_font('Arial', 'B', 15)
        w = self.get_string_width(title) + 6
        self.set_x((210-w)/2)
        self.set_draw_color(44, 116, 199)
        self.set_fill_color(152, 221, 250)
        self.set_text_color(199, 72, 44)
        self.set_line_width(1)
        # Move to the right
        self.cell(w, 9, title, 1, 1, 'C', 1)
        self.ln(3)
        pdf.cell(65, 10)
        self.cell(11, 9, title1,'C')
     

        # Line break
        self.ln(80)
        self.set_line_width(0.0)
        self.line(5.0,5.0,205.0,5.0) # top one
        self.line(5.0,292.0,205.0,292.0) # bottom one
        self.line(5.0,5.0,5.0,292.0) # left one
        self.line(205.0,5.0,205.0,292.0) # right one
  
        
        
    def chapter_body(self):
        # Read text file
        
        # Times 12
        self.set_font('Times', '', 12)
        w= 160
        h=100
        
        # Output justified text
        self.multi_cell(100, 50, 'hi')
        # Line break
        
        # Mention in italics
        self.set_font('', 'I')
        self.cell(0, 5, '(end of excerpt)')
       
   
        

    # Page footer
    def footer(self):
        # Position at 1.5 cm from bottom
        self.set_y(-15)
        # Arial italic 8
        self.set_font('Arial', 'I', 8)
        # Page number
        self.cell(0, 10, 'Page ' + str(self.page_no()) + '/{nb}', 0, 0, 'C')
     
# Instantiation of inherited class
pdf = PDF()

w= 160
h=100
pdf.alias_nb_pages()
pdf.add_page()
pdf.set_font('Times', '', 12)
pdf.cell(50, 10)
y= 110
pdf.cell(0,y,'The Optimal Actions to take over a 20 year period', 'C')
image1 = 'plot.png'
pdf.image(image1, x=23, y=50, w=w, h=h)
pdf.ln(90)
pdf.cell(60, 80)
pdf.set_fill_color(152, 221, 250)
pdf.cell(70, h = 15, txt = 'Click to go to our website for more info', border = 1, ln = 2, align = 'C', fill = True, link = 'http://127.0.0.1:8000/ ')

pdf.add_page()
image2 = '/Users/maekhaled/Desktop/Data/table1.png'
pdf.image(image2, x=23, y= 30, w=w, h=h)
pdf.cell(25, 10)
y= 70
pdf.cell(0,y,'The Optimal Actions to take over a 20 year period, including Investment Costs', 'C')


pdf.add_page()
image3 = '/Users/maekhaled/Desktop/Data/table2.png'
pdf.image(image3, x=23, y=30, w=w, h=h)
pdf.cell(50, 10)
y= 70
pdf.cell(0,y,'Storage Units List and Investment Costs', 'C')


pdf.add_page()
image4 = '/Users/maekhaled/Desktop/Data/table3.png'
pdf.image(image4, x=23, y= 30, w=w, h=h)
pdf.cell(50, 10)
y= 70
pdf.cell(0,y,'Power Plants List and Investment Costs', 'C')
pdf.output('results.pdf', 'F')





#email



import email, smtplib, ssl
import os
from email import encoders
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.image import MIMEImage

body =  """\
<html>
  <head></head>
    <body>
      <img src="cid:image1" alt="Logo" style="width:250px;height:50px;"><br>
       <p><h4 style="font-size:15px;">Some Text.</h4></p>           
    </body>
</html>
"""    

#Attached are your results! 

#Feel free to reply to this message if you have any questions.
#        We look forward to working with you soon.

#            Thank you for using Weckrogrid-20!                     
sender_email = "WeckroGrid-20"
receiver_email = "maekhaled17@gmail.com"

# Create a multipart message and set headers
message = MIMEMultipart()
message["From"] = 'WeckroGrid-20'
#message["To"] = 'elalam98@gmail.com'
message["Subject"] = 'Your Microgrid Plan is here!'
#message["Bcc"] = 'receiver_email'  # Recommended for mass emails

# Add body to email
#message.attach(MIMEText(body, "plain"))

filename = "results.pdf"  # In same directory as script

# Open PDF file in binary mode
with open(filename, "rb") as attachment:
    # Add file as application/octet-stream
    # Email client can usually download this automatically as attachment
    part = MIMEBase("application", "octet-stream")
    part.set_payload(attachment.read())
    
messageText = MIMEText('<br><img src="cid:weckroemail.jpg"><br>', 'html')
message.attach(messageText)
    
fp = open('weckroemail.jpg', 'rb')
messageImage = MIMEImage(fp.read())
fp.close()

messageImage.add_header('Content-ID', '<image1>')
message.attach(messageImage)

# Encode file in ASCII characters to send by email    
encoders.encode_base64(part)

# Add header as key/value pair to attachment part
part.add_header(
    "Content-Disposition",
    f"attachment; filename= {filename}",
)
#Add attachment to message and convert message to string
message.attach(part)
text = message.as_string('')

# Log in to server using secure context and send email
context = ssl.create_default_context()
with smtplib.SMTP_SSL("smtp.gmail.com", 465, context=context) as server:
    server.login('Weckrogrid20@gmail.com', 'jafari1234')
    server.sendmail(sender_email, receiver_email, text)