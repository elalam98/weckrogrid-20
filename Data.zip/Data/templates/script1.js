const btn1 = document.querySelector('button');
function sendData(){

  console.log("name, email");



}
