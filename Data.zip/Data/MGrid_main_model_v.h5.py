#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Oct 25 15:25:03 2020

@author: luisaweiss
"""
python manage.py runserver
