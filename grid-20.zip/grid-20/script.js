let mainCont = document.getElementById("main-container");

let question1 = `<h2>“1.Choose the facility that you wish to power”</h2>
<div class="box-container">
<div class="box" id="hospital">
  <label> <input type="checkbox" for="hospital"/>
  <img src="./images/Hospital Icon.png" alt="" />
  Hosipital
  </label>
  <br/>
  Quantity
  <br/>
  <input type="number" min="0" value="0"/>
</div>

<div class="box" id="outpatient">
  <label> <input type="checkbox" for="outpatient"/>
  <img src="./images/Outpatient Icon.png" alt="" />
  Outpatient </label>
  <br/>
  Quantity
  <br/>
  <input type="number" min="0" value="0"/>
</div>

<div class="box" id="supermarket">
  <label> <input type="checkbox" for="supermarket"/>
  <img src="./images/Supermarket Icon.png" alt="">
  Supermarket </label>
  <br/>
  Quantity
  <br/>
  <input type="number" min="0" value="0"/>
</div>

<div class="box" id="hotel">
    <label> <input type="checkbox" for="hotel"/>
    <img src="./images/Hotel Icon.png" alt="">
    Hotel </label>
    <br/>
    Quantity
    <br/>
    <input type="number" min="0" value="0"/>
</div>

<div class="box" id="office">
    <label> <input type="checkbox" for="office"/>
    <img src="./images/Office Icon.png" alt="">
    Office </label>
    <br/>
    Quantity
    <br/>
    <input type="number" min="0" value="0"/>
</div>

<div class="box" id="school">
    <label> <input type="checkbox" for="school"/>
    <img src="./images/School Icon.jpg" alt="">
    School </label>
    <br/>
    Quantity
    <br/>
    <input type="number" min="0" value="0"/>
</div>

<div class="box" id="restaurant">
    <label> <input type="checkbox" for="restaurant"/>
    <img src="./images/Restaurant Icon.png" alt="">
    Restaurant </label>
    <br/>
    Quantity
    <br/>
    <input type="number" min="0" value="0"/>
</div>

<div class="box" id="residential">
    <label> <input type="checkbox" for="residential"/>
    <img src="./images/Residential Icon.png" alt="">
    Residential </label>
    <br/>
    Quantity
    <br/>
    <input type="number" min="0" value="0"/>
</div>
</div>`;

let question2 = `<h1>“2. Choose your preferred power source”</h1>
<div class="box-container">
<div class="box">
<label>
<input type="radio" name="power-source">
<img src="./images/Solar Power Image.png"/>
<h4>Solar Power</h4>
<p>Solar power is pollution free and causes no greenhouse gases to be emitted after installation.</p>
</label>
</div>

<div class="box">
<label>
<input type="radio" name="power-source">
<img src="./images/Offshore Wind Power Image" alt="">
<h4>Offshore Wind Power</h4>
<p> Provide jobs and do not emit environmental pollutants or greenhouse gases (preference for near shore facilities) </p>
</label>
</div>

<div class="box">
<label>
<input type="radio" name="power-source">
<img src="./images/Onshore Wind Power Image" alt="">
<h4>Onshore Wind Power</h4>
<p> Provide jobs and do not emit environmental pollutants or greenhouse gases (preference for inland facilities) </p>
</label>
</div>

<div class="box">
<label>
<input type="radio" name="power-source">
<img src="./images/Diesel Power Image.png" alt="">
<h4>Diesel Power</h4>
<p> Fuel that is available without any weather conditions. Does not suffer loss in efficiency as technology improves</p>
</label>
</div>

</div>`;

let questions = [question1, question2];
let qNo = 0;
const generateQuestion = () => {
  mainCont.innerHTML = questions[qNo];
};
generateQuestion();

let nextBtn = document.getElementById("next-btn");
let boxes = document.querySelectorAll(".box");

let result1 = [];
let result2 = [];

function boxesLoop() {
  for (let i = 0; i < boxes.length; i++) {
    let box = boxes[i];
    let checkBox = box.firstElementChild.firstElementChild;
    box.addEventListener("click", function () {
      if (checkBox.checked == true && qNo == 0) {
        checkBox.parentElement.parentElement.style.border = "4px solid #007bff";
      } else if (checkBox.checked == true && qNo == 1) {
        result2 = this.firstElementChild.children[2].innerText;
        this.style.border = "4px solid #007bff";
        this.nextElementSibling.style.border = "4px solid #ffffff";
        this.previousElementSibling.style.border = "4px solid #ffffff";
      } else if (checkBox.checked == false && qNo == 0) {
        checkBox.parentElement.parentElement.style.border = "4px solid #ffffff";
      }
    });
  }
}
boxesLoop();

nextBtn.addEventListener("click", function () {
  for (let i = 0; i < boxes.length; i++) {
    let box = boxes[i];
    let checkBox = box.firstElementChild.firstElementChild;

    if (checkBox.checked == true && qNo == 0) {
      result1.push({
        name: checkBox.parentElement.parentElement.id,
        value: checkBox.parentElement.parentElement.lastElementChild.value,
      });
    }
  }
  qNo++;
  generateQuestion();
  boxes = document.querySelectorAll(".box");
  boxesLoop();
  console.log(result1);
});
