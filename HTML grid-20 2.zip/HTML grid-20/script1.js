const btn1 = document.querySelector('button');
function sendData(){

  console.log("you pressed da button");



}
